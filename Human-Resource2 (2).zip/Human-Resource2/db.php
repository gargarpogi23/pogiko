<?php
$host = 'localhost';
$dbname = 'hr2';
$user = 'root';
$pass = '';

// Use positional arguments without named arguments
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
