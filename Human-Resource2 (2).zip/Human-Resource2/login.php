
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login - Paradise Hotel</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">   
    </head>
    <?php

require 'db.php';

$sweetAlertScript = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch user data
        $user = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($password, $user['pass'])) {
            // Start a session and redirect to the dashboard
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];

            echo "<script>
                Swal.fire({
                    title: 'Login Successful!',
                    text: 'Welcome!',   
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'index.php';
                    }
                });
            </script>";
        } else {
            // Incorrect password
            echo "<script>
                Swal.fire({
                    title: 'Login Failed!',
                    text: 'Incorrect email or password.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            </script>";
        }
    } else {
        // Email not found
        echo "<script>
            Swal.fire({
                title: 'Login Failed!',
                text: 'Email not found.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>";
    }
}
?>
    <body class="bg-logo min-h-screen bg-cover bg-center bg-fixed" style="background-image: url('assets/img/background.jpg');">
    <div class="flex items-center justify-center min-h-screen">
        
            <div class="md:w-1/3 bg-white p-6 shadow-lg rounded-lg max-w-sm">
                <h2 class="text-center text-2xl font-bold text-primary mb-4 text-black">Login To Paradise Hotel</h2>
                <form action="login.php" method="POST" class="space-y-3">
                    <div class="flex justify-center space-x-4 mb-3">
                        <label class="flex flex-col items-center p-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 shadow-md">
                            <input type="radio" name="options" id="admin" />
                            <div class="icon mb-1">
                                <img src="assets/img/manager.png" alt="Manager Icon" class="w-8 h-8" />
                            </div>
                            <span class="text-sm text-black">I'm Manager</span>
                        </label>
                        <label class="flex flex-col items-center p-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 shadow-md">
                            <input type="radio" name="options" id="user"/>
                            <div class="icon mb-1">
                                <img src="assets/img/employee.png" alt="Employee Icon" class="w-8 h-8" />
                            </div>
                            <span class="text-sm text-black">I'm Employee</span>
                        </label>
                    </div>
                    <div class="flex justify-center space-x-4 mb-3">
                        <input type="email" name="email" placeholder="Email" required class="text-black w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                    </div>
                    <div>
                        <input type="password" name="password" placeholder="Password" required class="w-full p-2 border border-gray-300 text-black rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none" />
                    </div>
                    <div class="flex justify-between items-center mb-3">
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" class="form-checkbox text-blue-600" />
                            <span class="text-sm text-black">Remember me</span>
                        </label>
                        <a href="forgot-password.html" class="text-sm text-blue-500 hover:underline">Forgot Password?</a>
                    </div>
                    <button class="w-full bg-blue-500 text-white font-semibold py-2 rounded-lg hover:bg-blue-600 transition duration-300">
                        Sign In
                    </button>
                    <div class="text-center text-gray-500 font-medium my-2">OR</div>
                    <a href="signup.php" class="w-full block text-center border border-blue-500 text-blue-500 font-semibold py-2 rounded-lg hover:bg-blue-100 transition duration-300">
                        Register To Create Account
                    </a>
                </form>
            </div>
        </div>
    </div>
    <?php
// Output the SweetAlert script if needed
if ($sweetAlertScript) {
    echo $sweetAlertScript;
}
?>
</body>
    
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
            <script src="js/scripts.js"></script>
</html>
