
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">
<div class="flex items-center justify-between border border-gray-300 p-4 rounded-lg mb-4 bg-white">
    <div>
        <h4 class="text-4xl font-bold text-black">
            360-FEEDBACK
        </h4>
        <span class="text-gray-600">
            <a href="index.php" class="text-blue-500 hover:underline">Dashboard</a> / 360-Feedback
        </span>
    </div>
</div>
<div class="w-full mx-auto bg-white rounded-lg shadow-lg overflow-hidden text-black">
<section class="bg-white p-6 rounded-lg shadow-md w-full">
    <!-- Header with Title and Search Bar -->
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-semibold text-gray-700">Employees</h2>
                <div class="flex space-x-2">
            <input type="text" placeholder="Search employees..." class="p-2 border border-gray-300 rounded-lg focus:outline-none text-black focus:border-indigo-500" />
            <button class="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 focus:outline-none">Search</button>
            <button id="openModal" class="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 focus:outline-none">View</button>
        </div>
    </div>

            <!-- Employees Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full">
                <!-- Employee Card -->
                <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
                    <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
                    <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Erick Bustillo</h3>
                    <p class="text-gray-600 text-center">Developer</p>
                    <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
                    <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
                </div>
                <!-- Employee Card -->
                <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
                    <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
                    <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Edrian Luangki</h3>
                    <p class="text-gray-600 text-center">Developer</p>
                    <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
                    <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
                </div>
                <!-- Employee Card -->
                <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
                    <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
                    <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Raymond Lodronio</h3>
                    <p class="text-gray-600 text-center">Developer</p>
                    <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
                    <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
                </div>
                <!-- Employee Card -->
                <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
                    <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
                    <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Jerico Meca</h3>
                    <p class="text-gray-600 text-center">Developer</p>
                    <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
                    <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
                </div>
            </div>
        </section>

        <!-- Feedback Form Section -->
        <div class="bg-gray-50 p-6 rounded-lg shadow-sm">
          <h3 class="text-xl font-medium text-gray-700 mb-4">Feedback Form</h3>
          <form action="#" method="POST">
            <div class="space-y-6">
              <div>
                <label for="communication" class="block text-gray-600 font-medium">Communication:</label>
                <select id="communication" name="communication" class="w-full mt-2 p-2 border border-gray-300 rounded-lg">
                  <option value="1">1 - Poor</option>
                  <option value="2">2 - Fair</option>
                  <option value="3">3 - Good</option>
                  <option value="4">4 - Very Good</option>
                  <option value="5">5 - Excellent</option>
                </select>
              </div>

              <div>
                <label for="teamwork" class="block text-gray-600 font-medium">Teamwork:</label>
                <select id="teamwork" name="teamwork" class="w-full mt-2 p-2 border border-gray-300 rounded-lg">
                  <option value="1">1 - Poor</option>
                  <option value="2">2 - Fair</option>
                  <option value="3">3 - Good</option>
                  <option value="4">4 - Very Good</option>
                  <option value="5">5 - Excellent</option>
                </select>
              </div>

              <div>
                <label for="leadership" class="block text-gray-600 font-medium">Leadership:</label>
                <select id="leadership" name="leadership" class="w-full mt-2 p-2 border border-gray-300 rounded-lg">
                  <option value="1">1 - Poor</option>
                  <option value="2">2 - Fair</option>
                  <option value="3">3 - Good</option>
                  <option value="4">4 - Very Good</option>
                  <option value="5">5 - Excellent</option>
                </select>
              </div>

              <div>
                <label for="problem-solving" class="block text-gray-600 font-medium">Problem Solving:</label>
                <select id="problem-solving" name="problem-solving" class="w-full mt-2 p-2 border border-gray-300 rounded-lg">
                  <option value="1">1 - Poor</option>
                  <option value="2">2 - Fair</option>
                  <option value="3">3 - Good</option>
                  <option value="4">4 - Very Good</option>
                  <option value="5">5 - Excellent</option>
                </select>
              </div>

              <div>
                <label for="comments" class="block text-gray-600 font-medium">Additional Comments:</label>
                <textarea id="comments" name="comments" rows="4" class="w-full mt-2 p-2 border border-gray-300 rounded-lg" placeholder="Provide any additional comments here..."></textarea>
              </div>

              <div class="mt-6">
                <button type="submit" class="w-full py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:outline-none">Submit Feedback</button>
              </div>
            </div>
          </form>
        </div>
      </div>
</div>
</div>
                <!-- Feedback Modal -->
               <!-- Feedback Modal -->
<div id="nominationModal" class="fixed inset-0 bg-gray-500 bg-opacity-50 flex justify-center items-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-4xl w-full">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">360-Employee Feedback</h3>
        
        <!-- Feedback Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full table-auto border-collapse bg-white rounded-lg shadow-md">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-medium text-gray-600">Employee</th>
                        <th class="px-6 py-3 text-left text-sm font-medium text-gray-600">Role</th>
                        <th class="px-6 py-3 text-left text-sm font-medium text-gray-600">Feedback Status</th>
                        <th class="px-6 py-3 text-center text-sm font-medium text-gray-600">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Table Row 1 -->
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-4 text-sm text-gray-800">John Doe</td>
                        <td class="px-6 py-4 text-sm text-gray-800">Software Engineer</td>
                        <td class="px-6 py-4 text-sm text-gray-800">
                            <span class="text-yellow-600">Pending</span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <button class="text-blue-600 hover:text-blue-800 px-4 py-2 border border-blue-600 rounded-lg">View</button>
                            <button class="text-green-600 hover:text-green-800 px-4 py-2 border border-green-600 rounded-lg ml-2">Approve</button>
                            <button class="text-red-600 hover:text-red-800 px-4 py-2 border border-red-600 rounded-lg ml-2">Reject</button>
                        </td>
                    </tr>
                    <!-- Table Row 2 -->
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-6 py-4 text-sm text-gray-800">Jane Smith</td>
                        <td class="px-6 py-4 text-sm text-gray-800">Product Manager</td>
                        <td class="px-6 py-4 text-sm text-gray-800">
                            <span class="text-yellow-600">Pending</span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <button class="text-blue-600 hover:text-blue-800 px-4 py-2 border border-blue-600 rounded-lg">View</button>
                            <button class="text-green-600 hover:text-green-800 px-4 py-2 border border-green-600 rounded-lg ml-2">Approve</button>
                            <button class="text-red-600 hover:text-red-800 px-4 py-2 border border-red-600 rounded-lg ml-2">Reject</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Cancel Button -->
        <button onclick="closeNominationForm()" class="mt-6 w-full bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-800 focus:outline-none">
            Cancel
        </button>
    </div>
</div>


                <script>
            // Get the modal and button elements
            const nominationModal = document.getElementById('nominationModal');
            const openModalButton = document.getElementById('openModal');
            const closeModalButton = document.querySelector('[onclick="closeNominationForm()"]');

            // Open the modal when the 'View' button is clicked
            openModalButton.addEventListener('click', function() {
                nominationModal.classList.remove('hidden');  // Show modal
            });

            // Close the modal when the 'Cancel' button is clicked
            closeModalButton.addEventListener('click', function() {
                nominationModal.classList.add('hidden');  // Hide modal
            });
        </script>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
