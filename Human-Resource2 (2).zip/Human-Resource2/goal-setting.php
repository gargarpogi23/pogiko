<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>
<?php include 'includes/sidebar.php'; ?>
<div id="layoutSidenav_content">
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "hr2"; 
    
    $conn = new mysqli($servername, $username, $password, $dbname);


    // ADD FUNCTION
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if form is for adding a new goal
        if (isset($_POST['addGoalTitle'])) {
            $goalTitle = $_POST['addGoalTitle'];
            $goalDueDate = $_POST['addGoalDueDate'];
            $goalDescription = $_POST['addGoalDescription'];
            $progress = rand(0, 100);
            
            $stmt = $conn->prepare("INSERT INTO goals (GoalTitle, DueDate, GoalDesc, Progress) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssi", $goalTitle, $goalDueDate, $goalDescription, $progress);
            
            if ($stmt->execute()) {
                echo "<script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'New goal added successfully!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'goal-setting.php';
                    });
                </script>";
            }
        }
    }
    //FETCH THE DATA
    $sql = "SELECT ID, GoalTitle, DueDate, GoalDesc, Progress FROM goals";
    $result = $conn->query($sql);

    // Check if there are any goals
    if ($result->num_rows > 0) {
        // Loop through each goal
        while ($row = $result->fetch_assoc()) {
            // Extract data for each goal
            $goalTitle = $row['GoalTitle'];
            $dueDate = $row['DueDate'];
            $goalDesc = $row['GoalDesc'];
            $progress = $row['Progress'];

            // Determine the progress bar color based on the value
            if ($progress <= 40) {
                $progressColor = 'bg-red-500'; // Red for danger
            } elseif ($progress <= 80) {
                $progressColor = 'bg-green-500'; // Green for good
            } else {
                $progressColor = 'bg-blue-500'; // Blue for excellent
            }
        }
    }else{
        echo "<p class='text-red-500'>No goals found!</p>";
    }
    //DELETE FUNCTION
    if (isset($_GET['id'])) {
        $goalId = $_GET['id'];
    
        // Prepare the DELETE query
        $stmt = $conn->prepare("DELETE FROM goals WHERE ID = ?");
        $stmt->bind_param("i", $goalId);
    
        // Execute the DELETE statement
        if ($stmt->execute()) {
            // Redirect to goal-setting page after successful deletion
            echo "<script>
                    Swal.fire({
                        title: 'Deleted!',
                        text: 'Your goal has been deleted.',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'goal-setting.php'; 
                    });
                  </script>";
        } else {
            // If there's an error
            echo "<p class='text-red-500'>Error: " . $stmt->error . "</p>";
        }
    }
        //EDIT FUNCTION
        if (isset($_POST['editGoalId'])) {
            $goalId = $_POST['editGoalId'];
            $goalTitle = $_POST['editGoalTitle'];
            $goalDueDate = $_POST['editGoalDueDate'];
            $goalDescription = $_POST['editGoalDescription'];
            $progress = $_POST['editProgress'];
            
            $stmt = $conn->prepare("UPDATE goals SET GoalTitle = ?, DueDate = ?, GoalDesc = ?, Progress = ? WHERE ID = ?");
            $stmt->bind_param("sssii", $goalTitle, $goalDueDate, $goalDescription, $progress, $goalId);
            
            if ($stmt->execute()) {
                echo "<script>
                    Swal.fire({
                        title: 'Updated!',
                        text: 'Goal updated successfully!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = 'goal-setting.php';
                    });
                </script>";
            }
        }
            ?>


<div class="flex items-center justify-between border border-gray-300 p-4 rounded-lg mb-4 bg-white">
    <div>
        <h5 class="text-2xl font-bold text-black">
            Goal-Setting Management
        </h5>
        <span class="text-gray-600">
            <a href="index.php" class="text-blue-500 hover:underline">Dashboard</a> / Goal-Setting
        </span>
    </div>
</div>

<div class="w-full px-6 py-12">
    <div class="text-center mb-10">
        <p class="mt-2 text-lg text-gray-500">Stay on track and accomplish your goals</p>
    </div>

    <!-- Goal Setting Form -->
            <div class="bg-gray-100 p-6 rounded-lg shadow-lg mb-8 w-full">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Set New Goal</h2>
            <form action="goal-setting.php" method="POST">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                        <label for="addGoalTitle" class="block text-sm font-medium text-gray-700">Goal Title</label>
                        <input type="text" id="addGoalTitle" name="addGoalTitle" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required>
                    </div>
                    <div>
                        <label for="addGoalDueDate" class="block text-sm font-medium text-gray-700">Due Date</label>
                        <input type="date" id="addGoalDueDate" name="addGoalDueDate" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required>
                    </div>
                </div>
                <div class="mt-6">
                    <label for="addGoalDescription" class="block text-sm font-medium text-gray-700">Goal Description</label>
                    <textarea id="addGoalDescription" name="addGoalDescription" rows="4" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required></textarea>
                </div>
                <div class="mt-6">
                    <button type="submit" class="w-full bg-indigo-600 text-white p-3 rounded-md">Add Goal</button>
                </div>
            </form>
        </div>

        <div id="modalOverlay" class="fixed inset-0 bg-gray-900 bg-opacity-50 hidden"></div>
        <!-- Modal -->
            <div id="editModal" class="fixed inset-0 flex items-center justify-center hidden z-50">
        <div class="bg-gray-100 p-6 rounded-lg shadow-lg w-full max-w-lg">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold text-gray-800">Edit Goal</h2>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">&times;</button>
            </div>
            <form id="editGoalForm" action="goal-setting.php" method="POST">
                <input type="hidden" id="editGoalId" name="editGoalId">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                        <label for="editGoalTitle" class="block text-sm font-medium text-gray-700">Goal Title</label>
                        <input type="text" id="editGoalTitle" name="editGoalTitle" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required>
                    </div>
                    <div>
                        <label for="editGoalDueDate" class="block text-sm font-medium text-gray-700">Due Date</label>
                        <input type="date" id="editGoalDueDate" name="editGoalDueDate" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required>
                    </div>
                </div>
                <div class="mt-4">
                    <label for="editGoalDescription" class="block text-sm font-medium text-gray-700">Goal Description</label>
                    <textarea id="editGoalDescription" name="editGoalDescription" rows="4" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm" required></textarea>
                </div>
                <div class="mt-4">
                    <label for="editProgress" class="block text-sm font-medium text-gray-700">Progress</label>
                    <input type="number" id="editProgress" name="editProgress" min="0" max="100" class="mt-1 block w-full p-3 rounded-md text-black border shadow-sm">
                </div>
                <div class="mt-6">
                    <button type="submit" class="w-full bg-indigo-600 text-white p-3 rounded-md">Update Goal</button>
                </div>
            </form>
        </div>
    </div>


    <!-- Goal List with Progress Tracking -->
    <div class="space-y-6">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">Your Goals</h2>
    
    <?php
    // SQL to fetch goals
    $sql = "SELECT ID, GoalTitle, DueDate, GoalDesc, Progress FROM goals";
    $result = $conn->query($sql);

    // Check if there are any goals
    if ($result->num_rows > 0) {
        // Loop through each goal
        while ($row = $result->fetch_assoc()) {
            // Extract data for each goal
            $goalTitle = $row['GoalTitle'];
            $dueDate = $row['DueDate'];
            $goalDesc = $row['GoalDesc'];
            $progress = $row['Progress'];

            // Determine the progress bar color based on the value
            if ($progress <= 40) {
                $progressColor = 'bg-red-500'; // Red for danger
            } elseif ($progress <= 80) {
                $progressColor = 'bg-green-500'; // Green for good
            } else {
                $progressColor = 'bg-blue-500'; // Blue for excellent
            }
    ?>
    <!-- Display goal card -->
    <div class="bg-gray-50 p-6 rounded-lg shadow-md mb-4">
        <div class="flex justify-between">
            <div>
                <h3 class="text-lg font-semibold text-gray-800"><?php echo $goalTitle; ?></h3>
                <p class="text-sm text-gray-500">Due: <?php echo $dueDate; ?></p>
            </div>
            <div class="space-x-2">
              <button 
                onclick="openEditModal('<?php echo $row['ID']; ?>', '<?php echo addslashes($row['GoalTitle']); ?>', '<?php echo $row['DueDate']; ?>', '<?php echo addslashes($row['GoalDesc']); ?>', '<?php echo $row['Progress']; ?>')" 
                class="px-3 py-1 text-sm text-white bg-blue-500 rounded-md hover:bg-blue-600 focus:ring-4 focus:ring-blue-300">
                Edit
            </button>
               <button class="px-3 py-1 text-sm text-white bg-red-500 rounded-md hover:bg-red-600 focus:ring-4 focus:ring-red-300" 
                onclick="confirmDelete(<?php echo $row['ID']; ?>)">
                Delete
                 </button>
            </div>
        </div>
        <div class="mt-4">
            <p class="text-sm text-gray-600"><?php echo "Description: " . $goalDesc; ?></p>
        </div>
        <div class="mt-4">
            <label for="progress" class="block text-sm font-medium text-gray-700">Progress</label>
            <div class="w-full bg-gray-300 rounded-full h-3">
                <!-- Dynamic progress bar color based on the progress value -->
                <div class="h-3 rounded-full <?php echo $progressColor; ?>" style="width: <?php echo $progress; ?>%"></div>
            </div>
            <p class="mt-2 text-sm text-gray-500"><?php echo $progress; ?>% complete</p>
        </div>
    </div>

    <?php
        }
    } else {
        echo "<p class='text-red-500'>No goals found!</p>";
    }
    ?>

</div>
<script>
    function confirmDelete(goalId) {
        // Confirm with the user
        Swal.fire({
            title: 'Are you sure?',
            text: 'This action cannot be undone.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                // Send the goal ID to delete.php via a GET request
                window.location.href = 'goal-setting.php?id=' + goalId;
            }
        });
    }
</script>
<script>
    function openEditModal(id, title, dueDate, description, progress) {
        document.getElementById('editGoalId').value = id;
        document.getElementById('editGoalTitle').value = title;
        document.getElementById('editGoalDueDate').value = dueDate;
        document.getElementById('editGoalDescription').value = description;
        document.getElementById('editProgress').value = progress;

        document.getElementById('editModal').classList.remove('hidden');
        document.getElementById('modalOverlay').classList.remove('hidden');
    }

    function closeModal() {
        document.getElementById('editModal').classList.add('hidden');
        document.getElementById('modalOverlay').classList.add('hidden');
    }
</script>

<?php include 'includes/script.php'; ?>
<?php include 'includes/footer.php'; ?>
