<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hr2"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && (!isset($_POST['is_update']) || $_POST['is_update'] == '0')) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Handle file upload
    $image = $_FILES['image'];
    if ($image['error'] === 0) {
        $originalImageName = $image['name'];
        $imageNewName = uniqid('', true) . '.' . pathinfo($originalImageName, PATHINFO_EXTENSION);
        $imageDestination = 'assets/img/' . $imageNewName;
        if (move_uploaded_file($image['tmp_name'], $imageDestination)) {
            // Insert new record with the uploaded image
            $stmt = $conn->prepare("INSERT INTO appraisal (title, description, image) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $title, $description, $imageNewName); // Store the new image name

            if ($stmt->execute()) {
                echo "Record added successfully!";
            } else {
                echo "Error: " . $stmt->error;
            }
        } else {
            echo "Error uploading the image.";
        }
    } else {
        echo "There was an error with the file upload.";
    }
}

// Fetch data from the database to display
$sql = "SELECT title, description, image FROM appraisal"; 
$result = $conn->query($sql);

//DELETE FUNCTION
if (isset($_GET['id'])) {
    // Sanitize and prepare the ID
    $id = intval($_GET['id']);
    
    // Fetch the image name to delete the file from the server
    $imgQuery = $conn->prepare("SELECT image FROM appraisal WHERE id = ?");
    $imgQuery->bind_param("i", $id);
    $imgQuery->execute();
    $imgResult = $imgQuery->get_result();
    if ($imgResult->num_rows > 0) {
        $row = $imgResult->fetch_assoc();
        $imagePath = 'assets/img/' . $row['image'];
        
        // Delete the record from the database
        $stmt = $conn->prepare("DELETE FROM appraisal WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
            echo "<script>Swal.fire('Deleted!', 'The record has been deleted.', 'success');</script>";
        } else {
            echo "<script>Swal.fire('Error!', 'There was an error deleting the record.', 'error');</script>";
        }
    } else {
        echo "<script>Swal.fire('Error!', 'Record not found.', 'error');</script>";
    }
} else {
    echo "<script>Swal.fire('Error!', 'No ID specified.', 'error');</script>";
}
$sql = "SELECT id, title, description, image FROM appraisal"; 
$result = $conn->query($sql);

        //EDIT FUNCTION
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['is_update']) && $_POST['is_update'] == '1') {
            $id = intval($_POST['id']); // Ensure ID is valid
            $title = $_POST['title'];
            $description = $_POST['description'];
        
            if ($id > 0) {
                // Handle file upload for a new image
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $image = $_FILES['image'];
                    $imageNewName = uniqid('', true) . '.' . pathinfo($image['name'], PATHINFO_EXTENSION);
                    $imageDestination = 'assets/img/' . $imageNewName;
        
                    if (move_uploaded_file($image['tmp_name'], $imageDestination)) {
                        // Get the current image to delete if necessary
                        $imgQuery = $conn->prepare("SELECT image FROM appraisal WHERE id = ?");
                        $imgQuery->bind_param("i", $id);
                        $imgQuery->execute();
                        $currentImage = $imgQuery->get_result()->fetch_assoc()['image'];
        
                        // Update record with new image
                        $stmt = $conn->prepare("UPDATE appraisal SET title = ?, description = ?, image = ? WHERE id = ?");
                        $stmt->bind_param("sssi", $title, $description, $imageNewName, $id);
        
                        if ($stmt->execute()) {
                            // Remove old image if necessary
                            if (file_exists('assets/img/' . $currentImage)) {
                                unlink('assets/img/' . $currentImage);
                            }
                            echo "Record updated successfully!";
                        } else {
                            echo "Error updating the record.";
                        }
                    }
                } else {
                    // If no image uploaded, update without changing the image
                    $stmt = $conn->prepare("UPDATE appraisal SET title = ?, description = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $title, $description, $id);
        
                    if ($stmt->execute()) {
                        echo "Record updated successfully!";
                    } else {
                        echo "Error updating the record.";
                    }
                }
            } else {
                echo "Invalid ID for update.";
            }
        }
        $sql = "SELECT id, title, description, image FROM appraisal"; 
        $result = $conn->query($sql);

?>


<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">


<!-- Slide Left effect -->
<div class="flex items-center justify-between border border-gray-300 p-4 rounded-lg mb-4 bg-white">
    <h5 class="text-2xl text-blue-500 font-bold text-black">
        Appraisal Management System
    </h5>
    <button class="bg-green-500 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded-lg flex items-center" onclick="openModal()">
    <i class="fa fa-plus mr-2"></i>
           Add
        </button>
            </div>
            <div class="container mx-auto mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="card relative cursor-pointer">';
            echo '<div class="overflow-hidden rounded-lg shadow-lg relative">';

            // Image with corrected path
            echo '<img src="assets/img/' . htmlspecialchars($row['image']) . '" alt="Image" class="w-full h-64 object-cover" />';

            // Three dots menu in the upper-right corner
            echo '<div class="absolute top-2 right-2 z-10">';
            echo '    <button onclick="toggleMenu(this)" class="text-white p-2 rounded-full hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500">';
            echo '        <i class="fas fa-ellipsis-v"></i>'; // Three dots icon
            echo '    </button>';

            // Dropdown menu for Edit and Delete
            echo '    <div class="hidden absolute right-0 mt-2 w-24 bg-white rounded-lg shadow-lg text-black" style="z-index: 20;">';
            echo '        <button onclick="openEditModal(' . $row['id'] . ', \'' . addslashes($row['title']) . '\', \'' . addslashes($row['description']) . '\', \'' . $row['image'] . '\')" class="text-blue-500 w-full text-left px-4 py-2">Edit</button>';
            echo '<a href="#" onclick="confirmDelete(' . $row['id'] . ')" class="block px-4 py-2 hover:bg-gray-200 text-red-600">Delete</a>';
            echo '    </div>';
            echo '</div>';

            echo '<div class="overlay absolute inset-0 bg-white bg-opacity-10 flex items-center justify-center opacity-0 transition-opacity duration-300 backdrop-blur-lg border border-white border-opacity-30 hover:opacity-100">';
            echo '<a href="https://www.youtube.com" target="_blank">';
            echo '<i class="fas fa-play text-white text-4xl"></i>';
            echo '</a>';
            echo '</div>';
            echo '</div>';

            echo '<div class="mt-4 text-center text-black">';
            echo '<h5 class="text-lg font-semibold mb-2">' . htmlspecialchars($row['title']) . '</h5>';
            echo '<p class="text-gray-600">' . htmlspecialchars($row['description']) . '</p>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "No records found.";
    }
    ?>
</div>
                    <!-- MODAL FOR ADD -->
                    <div id="AddModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center hidden">
                    <div class="bg-white p-6 rounded-lg shadow-lg w-96">
                        <h2 class="text-xl font-semibold mb-4 text-black">ADD APPRAISAL</h2>
                        <form id="addForm" action="appraisal.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="is_update" value="0">
                            <input type="hidden" id="add-id" name="id" value="">

                            <div class="mb-4">
                                <label for="title" class="block text-sm font-medium text-black">Title</label>
                                <input type="text" id="add-title" name="title" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-black" required>
                            </div>
                            <div class="mb-4">
                                <label for="description" class="block text-sm font-medium text-black">Description</label>
                                <textarea id="add-description" name="description" rows="4" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-black" required></textarea>
                            </div>
                            <div class="mb-4">
                                <label for="image" class="block text-sm font-medium text-black">Upload New Image</label>
                                <input type="file" id="add-image" name="image" class="mt-1 block w-full text-sm text-black text-gray-700 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
                            </div>
                            <div class="flex justify-end space-x-2">
                                <button type="button" class="bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-md" onclick="closeAddModal()">Cancel</button>
                                <button type="submit" class="bg-green-500 hover:bg-green-700 text-white py-2 px-4 rounded-md">Save</button>
                            </div>
                        </form>
                    </div>
                </div>


                    <!-- Edit Modal -->
                    <div id="EditModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center hidden">
                <div class="bg-white p-6 rounded-lg shadow-lg w-96">
                    <h2 class="text-xl font-semibold mb-4 text-black">EDIT APPRAISAL</h2>
                    <form id="editForm" action="appraisal.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="is_update" value="1"> <!-- 1 for Edit -->
                        <input type="hidden" id="edit-id" name="id" value="">

                        <div class="mb-4">
                            <label for="title" class="block text-sm font-medium text-black">Title</label>
                            <input type="text" id="edit-title" name="title" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-black" required>
                        </div>
                        <div class="mb-4">
                            <label for="description" class="block text-sm font-medium text-black">Description</label>
                            <textarea id="edit-description" name="description" rows="4" class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500 text-black" required></textarea>
                        </div>
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-black">Previous Image</label>
                            <img id="edit-previous-image" src="" alt="Previous Image" class="w-full h-32 object-cover rounded-md mt-2">
                        </div>
                        <div class="mb-4">
                            <label for="image" class="block text-sm font-medium text-black">Upload New Image</label>
                            <input type="file" id="edit-image" name="image" class="mt-1 block w-full text-sm text-black text-gray-700 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
                        </div>
                        <div class="flex justify-end space-x-2">
                            <button type="button" class="bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 px-4 rounded-md" onclick="closeEditModal()">Cancel</button>
                            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white py-2 px-4 rounded-md">Save</button>
                        </div>
                    </form>
                </div>
            </div>


        <script>
    function openEditModal(id, title, description, imagePath) {
        // Populate modal fields with record data
        document.getElementById('edit-id').value = id;
        document.getElementById('edit-title').value = title;
        document.getElementById('edit-description').value = description;
        document.getElementById('edit-previous-image').src = 'assets/img/' + imagePath;

        // Show the modal
        document.getElementById('EditModal').classList.remove('hidden');
    }

    function closeEditModal() {
        document.getElementById('EditModal').classList.add('hidden');
    }
</script>

<script>
    function openModal() {
        document.getElementById('AddModal').classList.remove('hidden');
    }

    function closeAddModal() {
        document.getElementById('AddModal').classList.add('hidden');
    }
</script>

<script>
    // Function to toggle the dropdown menu
    function toggleMenu(button) {
        const menu = button.nextElementSibling; // The next sibling is the dropdown menu
        menu.classList.toggle('hidden'); // Toggle visibility of the menu
    }

    // Close the dropdown if clicked outside
    document.addEventListener('click', function(event) {
        const menus = document.querySelectorAll('.card .absolute .hidden');
        menus.forEach(menu => {
            if (!menu.contains(event.target) && !menu.previousElementSibling.contains(event.target)) {
                menu.classList.add('hidden');
            }
        });
    });

    // Hover effect for overlay
    document.addEventListener("DOMContentLoaded", function() {
        const cards = document.querySelectorAll(".card"); // Select all cards
        cards.forEach(card => {
            const overlay = card.querySelector(".overlay"); // Select the overlay inside the card

            card.addEventListener("mouseenter", () => {
                overlay.classList.remove("opacity-0");
                overlay.classList.add("opacity-100");
            });

            card.addEventListener("mouseleave", () => {
                overlay.classList.remove("opacity-100");
                overlay.classList.add("opacity-0");
            });
        });
    });
</script>
<script>
function confirmDelete(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Redirect to the same page with the delete ID
            window.location.href = 'appraisal.php?id=' + id;
        }
    });
}
</script>



<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
