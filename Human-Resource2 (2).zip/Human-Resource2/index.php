<?php include 'includes/header.php'?>
<?php include 'includes/navbar.php'?>
           <?php include 'includes/sidebar.php'?>
           
           <div id="layoutSidenav_content">
    <main>  
        <div class="container-fluid px-4 mx-auto">
        <h1 class="mt-4 text-5xl text-black">Dashboard</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active text-green">Dashboard</li>
            </ol>

            <!-- Card Section -->
            <div class="row">
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-blue-500 text-white mb-4">
                        <div class="card-body">Total Employees</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-green-500 text-white mb-4">
                        <div class="card-body">Achievements</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-yellow-500 text-white mb-4">
                        <div class="card-body">Performance</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="card bg-pink-500 text-white mb-4">
                        <div class="card-body">Rewards</div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">View Details</a>
                            <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                        </div>
                    </div>
                </div>
                
            </div>

          
            <div class="row">
                <div class="col-xl-6">
                    <div class="card mb-4">
                        <div class="card-header text-black">
                            <i class="fas fa-chart-area me-1 "></i> Area Chart Example
                        </div>
                        <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="card mb-4">
                        <div class="card-header text-black">
                            <i class="fas fa-chart-bar me-1"></i> Bar Chart Example
                        </div>
                        <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                    </div>
                </div>
            </div>

            <!-- DataTable Section -->
            <div class="card mb-4 border border-gray-200 rounded-lg overflow-hidden text-black">
    <div class="card-header p-3 border-b bg-gray-50 flex items-center">
        <i class="fas fa-table mr-2 text-gray-700"></i>
        <span class="font-semibold text-gray-700">Employee List</span>
    </div>
    <div class="p-1 bg-white">
        <div class="overflow-x-auto container-fluid">
            <table class="min-w-full w-100 table-auto bg-white border border-gray-200">
                <thead>
                    <tr class="bg-gray-100 text-left text-sm font-semibold text-gray-700">
                        <th class="p-3 border-b-2 border-gray-200">Name</th>
                        <th class="p-3 border-b-2 border-gray-200">Gender</th>
                        <th class="p-3 border-b-2 border-gray-200">Skills</th>
                        <th class="p-3 border-b-2 border-gray-200">Doctor</th>
                        <th class="p-3 border-b-2 border-gray-200">Admit</th>
                        <th class="p-3 border-b-2 border-gray-200">Progress</th>
                        <th class="p-3 border-b-2 border-gray-200">Actions</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700 divide-y divide-gray-200">
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <div class="flex items-center">
                            <img src="assets/img/kap.jpg" class="rounded-full w-12 h-12 mr-3 shadow-md" alt="Jennifer O. Oster's Avatar" />
                                <span class="font-medium">Kap-Nino</span>
                            </div>
                        </td>
                        <td class="p-4">Female</td>
                        <td class="p-4">45 kg</td>
                        <td class="p-4">Dr. Callie Reed</td>
                        <td class="p-4">19 Oct 2020</td>
                        <td class="p-4">
                            <span class="bg-green-100 text-black-600 px-3 py-1 rounded-full text-xs">Active</span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-3">
                                <a href="#" class="text-blue-600 hover:text-blue-800" aria-label="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-700" aria-label="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <div class="flex items-center">
                            <img src="assets/img/kap.jpg" class="rounded-full w-12 h-12 mr-3 shadow-md" alt="Jennifer O. Oster's Avatar" />
                                <span class="font-medium">Kap-Nino</span>
                            </div>
                        </td>
                        <td class="p-4">Female</td>
                        <td class="p-4">45 kg</td>
                        <td class="p-4">Dr. Callie Reed</td>
                        <td class="p-4">19 Oct 2020</td>
                        <td class="p-4">
                            <span class="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-xs">Processing</span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-3">
                                <a href="#" class="text-blue-600 hover:text-blue-800" aria-label="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-700" aria-label="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <div class="flex items-center">
                            <img src="assets/img/kap.jpg" class="rounded-full w-12 h-12 mr-3 shadow-md" alt="Jennifer O. Oster's Avatar" />
                                <span class="font-medium">Kap-Nino</span>
                            </div>
                        </td>
                        <td class="p-4">Female</td>
                        <td class="p-4">45 kg</td>
                        <td class="p-4">Dr. Callie Reed</td>
                        <td class="p-4">19 Oct 2020</td>
                        <td class="p-4">
                        <span class="bg-green-100 text-black-600 px-3 py-1 rounded-full text-xs">Active</span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-3">
                                <a href="#" class="text-blue-600 hover:text-blue-800" aria-label="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-700" aria-label="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <div class="flex items-center">
                            <img src="assets/img/kap.jpg" class="rounded-full w-12 h-12 mr-3 shadow-md" alt="Jennifer O. Oster's Avatar" />
                                <span class="font-medium">Kap-Nino</span>
                            </div>
                        </td>
                        <td class="p-4">Female</td>
                        <td class="p-4">45 kg</td>
                        <td class="p-4">Dr. Callie Reed</td>
                        <td class="p-4">19 Oct 2020</td>
                        <td class="p-4">
                        <span class="bg-green-100 text-black-600 px-3 py-1 rounded-full text-xs">Active</span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-3">
                                <a href="#" class="text-blue-600 hover:text-blue-800" aria-label="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-700" aria-label="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50">
                        <td class="p-4">
                            <div class="flex items-center">
                            <img src="assets/img/kap.jpg" class="rounded-full w-12 h-12 mr-3 shadow-md" alt="Jennifer O. Oster's Avatar" />
                                <span class="font-medium">Kap-Nino</span>
                            </div>
                        </td>
                        <td class="p-4">Female</td>
                        <td class="p-4">45 kg</td>
                        <td class="p-4">Dr. Callie Reed</td>
                        <td class="p-4">19 Oct 2020</td>
                        <td class="p-4">
                        <span class="bg-green-100 text-black-600 px-3 py-1 rounded-full text-xs">Active</span>
                        </td>
                        <td class="p-4">
                            <div class="flex space-x-3">
                                <a href="#" class="text-blue-600 hover:text-blue-800" aria-label="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <a href="#" class="text-red-500 hover:text-red-700" aria-label="Delete">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <!-- Repeat for each row as needed -->
                </tbody>
            </table>
        </div>
    </div>
</div>

    </main>


<?php include 'includes/script.php'?>
<?php include 'includes/footer.php'?>