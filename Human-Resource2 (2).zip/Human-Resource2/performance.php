
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php'?>
<?php include 'includes/sidebar.php'?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Futuristic Performance Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #e0f7fa 30%, #80deea 70%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #333;
        }
        .card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.15);
        }
        .employee-photo {
            border: 4px solid #00b4d8;
        }
        .chart-container {
            height: 600px; /* Fixed height */
            position: relative;
            margin-bottom: 30px; /* Increased space below the chart */
        }
        h2 {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }
        .employee-list li {
            transition: background-color 0.3s, transform 0.2s;
        }
        .employee-list li:hover {
            background-color: #38a169;
            color: white;
            transform: scale(1.05);
        }
        .tooltip {
            display: none;
            position: absolute;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px;
            border-radius: 5px;
            font-size: 12px;
            pointer-events: none;
            z-index: 10;
        }
        .metric-card {
            transition: transform 0.3s;
            padding: 20px; /* Increased padding inside the metric cards */
            margin-right: 10px; /* Add right margin between cards */
        }
        .metric-card:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body class="h-screen">
    <div class="flex h-full">
        <div class="w-1/4 bg-white p-4 shadow-md card overflow-y-auto text-black">
        <h1 class="text-green-700 text-2xl font-bold mb-4 text-center text-black">Performance Management System</h1>

<h2 class="text-green-700 text-lg font-semibold mb-4 text-black">Employee Profile</h2>
<div class="bg-gray-100 p-2 rounded-lg mb-6 flex items-center text-black">
                <?php
                require_once('db.php');
                $firstName = $lastName = $email = '';
                $query = "SELECT id, firstname, lastname, email FROM users";
                $result = mysqli_query($conn, $query);

                if ($result && mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);
                    $firstName = $row['firstname'];
                    $lastName = $row['lastname'];
                    $email = $row['email'];
                }
                ?>
                <img id="profile-pic" class="w-16 h-16 rounded-full border-4 employee-photo" src="assets/img/kap.jpg" alt="Employee Photo">
        <div id="profile-section" class="ml-4 text-black">
    <p id="profile-name" class="text-lg text-black"><?php echo htmlspecialchars($firstName . " " . $lastName); ?></p>
    <p id="profile-email" class="text-black text-sm">Email: <?php echo htmlspecialchars($email); ?></p>
</div>
    </div>
            
            <div class="ml-2 text-black">
            <div class="ml-2 text-black">
    <h2 class="text-green-700 text-lg font-semibold mb-2 text-black">Employee List</h2>
    <div class="space-y-2 text-black">
    <?php
        while ($row = mysqli_fetch_assoc($result)) {
            $id = htmlspecialchars($row['id']);
            $fullName = ucwords(htmlspecialchars($row['firstname']) . " " . htmlspecialchars($row['lastname']));
            echo "<div class='py-2 px-4 hover:bg-gray-100 rounded cursor-pointer'>";
            echo "<a href='#' class='text-black' onclick='updateProfile($id)'>$id - $fullName</a>";
            echo "</div>";
        }
        ?>
    </div>
</div>
        
    </div>
    </div>
        <!-- Main content area -->
        <div class="w-3/4 ml-6 h-full overflow-y-auto">
    <!-- Performance Metrics Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-4">Performance Metrics (Monthly)</h2>
                <div class="chart-container">
                    <canvas id="performanceChart" class="h-full"></canvas>
                    <div id="tooltip" class="tooltip"></div>
                </div>
                <div class="flex justify-between mt-4">
                    <!-- Performance Score -->
                    <div class="bg-gradient-to-r from-green-400 to-blue-500 p-4 rounded-lg text-center metric-card w-1/3">
                        <h3 class="text-white text-sm font-semibold">Performance Score</h3>
                        <p id="performance-score" class="text-2xl font-bold text-white">85%</p>
                    </div>
                    <!-- Rank -->
                    <div class="bg-gradient-to-r from-blue-400 to-purple-500 p-4 rounded-lg text-center metric-card w-1/3">
                        <h3 class="text-white text-sm font-semibold">Rank</h3>
                        <p id="performance-rank" class="text-2xl font-bold text-white">3rd</p>
                    </div>
                </div>
            </div>
            <!-- Employee Goals Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-2">Goals Achieved</h2>
                <ul id="goal-list" class="list-disc pl-5">
                    <li>Implemented new features in project A</li>
                    <li>Increased team efficiency by 15%</li>
                    <li>Reduced code errors by 10%</li>
                </ul>
            </div>

            <!-- Performance Reviews Section -->
            <div class="bg-white p-4 shadow-md card mb-6">
                <h2 class="text-green-700 text-lg font-semibold mb-2">Performance Reviews</h2>
                <div id="review-list" class="reviews">
                    <p>Great coding skills</p>
                    <p>Needs to improve time management</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Include Chart.js -->
    <script>
    function updateProfile(employeeId) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'fetch_profile.php?id=' + employeeId, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var data = JSON.parse(xhr.responseText);
                document.getElementById('profile-name').textContent = data.firstname + " " + data.lastname;
                document.getElementById('profile-email').textContent = "Email: " + data.email;
            }
        };
        xhr.send();
    }
</script>
<script>
                let previousProfile = null;

                function updateProfile(employeeId) {
                    const xhr = new XMLHttpRequest();
                    xhr.open("GET", "get_employee_profile.php?id=" + employeeId, true);
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            const response = JSON.parse(xhr.responseText);
                            if (previousProfile) {
                                const employeeList = document.getElementById("employee-list");
                                const profileDiv = document.createElement("div");
                                profileDiv.className = "py-2 px-4 hover:bg-gray-100 rounded cursor-pointer";
                                profileDiv.innerHTML = `<a href='#' class='text-black' onclick='updateProfile(${previousProfile.id})'>${previousProfile.id} - ${previousProfile.fullName}</a>`;
                                employeeList.appendChild(profileDiv);
                            }
                            document.getElementById("profile-name").textContent = response.fullName;
                            document.getElementById("profile-email").textContent = "Email: " + response.email;

                           
                            previousProfile = {
                                id: employeeId,
                                fullName: response.fullName
                            };
                        }
                    };
                    xhr.send();
                }
                </script>
<script>
function updateProfile(employeeId) {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "get_employee_profile.php?id=" + employeeId, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            document.getElementById("profile-name").textContent = response.fullName;
            document.getElementById("profile-email").textContent = "Email: " + response.email;
            document.getElementById("profile-pic").src = response.photoUrl; // Ensure your response has this value
        }
    };
    xhr.send();
}
</script>
<script>
    // Initialize the chart
    const ctx = document.getElementById('performanceChart').getContext('2d');
    const performanceChart = new Chart(ctx, {
        type: 'bar', // Example chart type
        data: {
            labels: ['Communications', 'Leadership', 'Problem Solving', 'Adaptability'],
            datasets: [{
                label: 'Performance Metrics',
                data: [20, 30, 40, 50], 
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    
    function updateProfile(employeeId) {
        
        const performanceData = {
            score: Math.floor(Math.random() * 100) + '%', 
            rank: `${Math.floor(Math.random() * 10) + 1}th`, 
            metrics: Array.from({ length: 4 }, () => Math.floor(Math.random() * 100)) // Random data for chart
        };

        // Update the performance score and rank
        document.getElementById('performance-score').innerText = performanceData.score;
        document.getElementById('performance-rank').innerText = performanceData.rank;

        // Update the chart data
        performanceChart.data.datasets[0].data = performanceData.metrics;
        performanceChart.update();
    }
</script>

</body>

</html>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
