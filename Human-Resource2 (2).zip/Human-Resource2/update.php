            <?php
            $host = 'localhost';
            $dbname = 'hr2';
            $user = 'root';
            $pass = '';
            $conn = new mysqli($host, $user, $pass, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if (isset($_POST['id']) && isset($_POST['status'])) {
                $id = $_POST['id'];
                $status = $_POST['status'];

                // Update the nomination status in the database
                $sql = "UPDATE nominate SET status = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("si", $status, $id);

                if ($stmt->execute()) {
                    echo "success";
                } else {
                    echo "error";
                }
                $stmt->close();
                $conn->close();
            }
            ?>