

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register - Paradise Hotel</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">   
    </head>
    <?php
// Include database connection
require 'db.php';

$sweetAlertScript = ""; // Variable to hold SweetAlert script

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['pass'];

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Check if email already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email already exists
        $sweetAlertScript = "<script>
            Swal.fire({
                title: 'Email Already Exists!',
                text: 'Please use a different email to register.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        </script>";
    } else {
        // Insert user data into the database
        $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, email, pass) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $firstname, $lastname, $email, $hashedPassword);

        if ($stmt->execute()) {
            // Registration successful
            $sweetAlertScript = "<script>
                Swal.fire({
                    title: 'Account Created!',
                    text: 'Your account has been successfully created.',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'login.php';
                    }
                });
            </script>";
        } else {
            // Error during registration
            $sweetAlertScript = "<script>
                Swal.fire({
                    title: 'Registration Failed!',
                    text: 'There was an error during registration. Please try again.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            </script>";
        }
    }
}
?>
    <body class="bg-logo min-h-screen bg-cover bg-center bg-fixed" style="background-image: url('assets/img/background.jpg');">
    <div class="flex items-center justify-center min-h-screen">
        
            <div class="md:w-1/3 bg-white p-6 shadow-lg rounded-lg max-w-sm">
                <h2 class="text-center text-2xl text-primary mb-4 text-black">Register To Paradise Hotel</h2>
                <form class="space-y-3" action="signup.php" method="POST">
                    <div class="flex justify-center space-x-4 mb-3">
                        <label class="flex flex-col items-center p-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 shadow-md">
                            <input type="radio" name="options" id="admin" />
                            <div class="icon mb-1">
                                <img src="assets/img/manager.png" alt="Manager Icon" class="w-8 h-8" />
                            </div>
                            <span class="text-sm text-black">I'm Manager</span>
                        </label>
                        <label class="flex flex-col items-center p-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-100 active:bg-gray-200 shadow-md">
                            <input type="radio" name="options" id="user"/>
                            <div class="icon mb-1">
                                <img src="assets/img/employee.png" alt="Employee Icon" class="w-8 h-8" />
                            </div>
                            <span class="text-sm text-black">I'm Employee</span>
                        </label>
                    </div>
                    <div class="text-black">
                        <label for="inputFirstName">First name</label>
                    <input class="form-control" id="inputFirstName" type="text" name="firstname" placeholder="Enter your first name" required />
                    
                    </div>
                    <div class="text-black">
                        <label for="inputLastName">Last name</label>
                    <input class="form-control" id="inputLastName" type="text" name="lastname" placeholder="Enter your last name" required />
                    </div>
                    <div class="text-black">
                        <label for="inputEmail">Email address</label>
                    <input class="form-control" id="inputEmail" type="email" name="email" placeholder="name@example.com" required />
                    <div>
                        <label for="inputPassword">Password</label>
                    <input class="form-control" id="inputPassword" type="password" name="pass" placeholder="Enter your password" required />                        
                    </div>
                    <div> 
                    <label for="inputPasswordConfirm">Confirm Password</label> 
                    <input class="form-control" id="inputPasswordConfirm" type="password" placeholder="Confirm your password" required />
                                         
                    </div>
                    <div class="flex justify-between items-center mb-3">
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" class="form-checkbox text-blue-600" />
                            <span class="text-sm">Remember me</span>
                        </label>
                        <a href="forgot-password.html" class="text-sm text-blue-500 hover:underline">Forgot Password?</a>
                    </div>

                    <button type="submit" class="w-full bg-blue-500 text-white font-semibold py-2 rounded-lg hover:bg-blue-600 transition duration-300">
                     Sign Up
                    </button>
                    <div class="text-center text-gray-500 font-medium my-2">OR</div>
                    <a href="login.php" class="w-full block text-center border border-blue-500 text-blue-500 font-semibold py-2 rounded-lg hover:bg-blue-100 transition duration-300">
                        Already Have account?
                    </a>
                </form>
            </div>
        </div>
    </div>
    <?php
// Output the SweetAlert script if needed
if ($sweetAlertScript) {
    echo $sweetAlertScript;
}
?>
</body>

    
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
            <script src="js/scripts.js"></script>
</html>
