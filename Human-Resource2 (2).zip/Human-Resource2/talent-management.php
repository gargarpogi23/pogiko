
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Talent Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f0f4f8, #e2e8f0); /* Light gradient background */
            color: #333; /* Darker text color for contrast */
        }
    </style>
</head>
<body class="font-sans">

    <!-- Navbar -->
    <nav class="bg-white p-4 shadow-md">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-gray-800 text-2xl font-bold">Talent Management</h1>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mx-auto mt-6">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Employee Profile Card -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
    <img src="https://via.placeholder.com/150" alt="Employee" class="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-green-500 transition-transform transform hover:scale-105">
                <h2 class="text-xl text-gray-800 font-semibold">John Doe</h2>
                <p class="text-gray-600">Role: Software Engineer</p>
                <p class="text-gray-600">Department: IT</p>
                <p class="text-gray-600">Email: john.doe@example.com</p>
                <p class="text-gray-600">Phone: (123) 456-7890</p>
                <div class="mt-4">
                    <h3 class="text-lg text-blue-500">Performance Metrics</h3>
                    <p class="text-gray-600">Goals Achieved: 5/7</p>
                    <p class="text-gray-600">Last Review: Excellent</p>
                    <p class="text-gray-600">Skill Level: Advanced</p>
                    <p class="text-gray-600">Tenure: 3 years</p>
                </div>
                <canvas id="performanceChart1" class="mt-4"></canvas>
                <div class="flex justify-between mt-4">
                    <button class="bg-yellow-500 text-white py-1 px-2 rounded hover:bg-yellow-600 transition-colors">Edit</button>
                    <button class="bg-red-500 text-white py-1 px-2 rounded hover:bg-red-600 transition-colors">Delete</button>
                </div>
            </div>

            <!-- Employee Profile Card -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
    <img src="https://via.placeholder.com/150" alt="Employee" class="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-green-500 transition-transform transform hover:scale-105">
                <h2 class="text-xl text-gray-800 font-semibold">Jane Smith</h2>
                <p class="text-gray-600">Role: Project Manager</p>
                <p class="text-gray-600">Department: Operations</p>
                <p class="text-gray-600">Email: jane.smith@example.com</p>
                <p class="text-gray-600">Phone: (098) 765-4321</p>
                <div class="mt-4">
                    <h3 class="text-lg text-blue-500">Performance Metrics</h3>
                    <p class="text-gray-600">Goals Achieved: 6/7</p>
                    <p class="text-gray-600">Last Review: Very Good</p>
                    <p class="text-gray-600">Skill Level: Intermediate</p>
                    <p class="text-gray-600">Tenure: 2 years</p>
                </div>
                <canvas id="performanceChart2" class="mt-4"></canvas>
                <div class="flex justify-between mt-4">
                    <button class="bg-yellow-500 text-white py-1 px-2 rounded hover:bg-yellow-600 transition-colors">Edit</button>
                    <button class="bg-red-500 text-white py-1 px-2 rounded hover:bg-red-600 transition-colors">Delete</button>
                </div>
            </div>

            <!-- Add Employee Button -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 flex items-center justify-center">
                <button class="bg-blue-500 text-white py-2 px-4 rounded-full hover:bg-blue-600 transition-colors">
                    <span class="mr-2">+</span> Add Employee
                </button>
            </div>
        </div>
    </div>

    <!-- Talent Development Section -->
    <div class="container mx-auto mt-10">
        <h2 class="text-gray-800 text-2xl font-bold mb-4">Talent Development</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <!-- Training Programs -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
                <h3 class="text-lg text-blue-500 font-semibold mb-2">Training Programs</h3>
                <p class="text-gray-600">Courses offered in advanced skills, leadership training, and role-specific knowledge. Enroll now to elevate your skillset!</p>
                <button class="bg-blue-500 text-white py-2 px-4 rounded mt-4 hover:bg-blue-600 transition-colors">View Courses</button>
            </div>

            <!-- Mentorship -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
                <h3 class="text-lg text-blue-500 font-semibold mb-2">Mentorship</h3>
                <p class="text-gray-600">Pair with an experienced mentor to accelerate your growth, receive guidance, and unlock your potential.</p>
                <button class="bg-blue-500 text-white py-2 px-4 rounded mt-4 hover:bg-blue-600 transition-colors">Find a Mentor</button>
            </div>

            <!-- Skill Development -->
            <div class="bg-white p-5 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
                <h3 class="text-lg text-blue-500 font-semibold mb-2">Skill Development</h3>
                <p class="text-gray-600">Gain new competencies through hands-on workshops, e-learning, and collaborative projects.</p>
                <button class="bg-blue-500 text-white py-2 px-4 rounded mt-4 hover:bg-blue-600 transition-colors">Explore Skills</button>
            </div>
        </div>
    </div>

    <!-- Performance Charts -->
    <script>
        // Chart for John Doe's performance
        const ctx1 = document.getElementById('performanceChart1').getContext('2d');
        new Chart(ctx1, {
            type: 'bar',
            data: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [{
                    label: 'Performance',
                    data: [4, 5, 4.5, 5],
                    backgroundColor: 'rgba(75, 192, 192, 0.6)'
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Chart for Jane Smith's performance
        const ctx2 = document.getElementById('performanceChart2').getContext('2d');
        new Chart(ctx2, {
            type: 'line',
            data: {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                datasets: [{
                    l,
                    label: 'Performance',
                    data: [4, 4.5, 4, 5],
                    backgroundColor: 'rgba(255, 99, 132, 0.6)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    fill: false
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>
</html>

<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
