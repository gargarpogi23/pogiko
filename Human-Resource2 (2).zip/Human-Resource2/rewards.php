
<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Recognition System</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Light Mode Futuristic Styling */
        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            transition: box-shadow 0.3s;
        }

        .card:hover {
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }

        /* Button with Subtle Gradient */
        .button-gradient {
            background: linear-gradient(to right, #f8f9fa, #e9ecef);
            color: #333;
            border: 1px solid #ced4da;
            border-radius: 5px;
            padding: 0.5rem 1rem;
            transition: background 0.3s;
        }

        .button-gradient:hover {
            background: linear-gradient(to right, #e9ecef, #dee2e6);
        }

        /* Header Styling */
        .header-title {
            color: #333;
            font-weight: bold;
            font-size: 1.8rem;
            text-align: center;
            margin-bottom: 1rem;
        }

        /* Highlight Animation for Reward */
        .highlight-reward {
            animation: highlight 1s ease;
        }

        @keyframes highlight {
            0% { background-color: #e2f3e1; }
            50% { background-color: #cfe9cd; }
            100% { background-color: transparent; }
        }
    </style>
</head>

<body>

    <!-- Header -->
    <header class="p-0">
        <h1 class="header-title">Employee Recognition System</h1>
    </header>

    <!-- Main Content -->
    <main class="p-8">

       <!-- Employee Display -->
        <section class="card text-center mb-10">
         <h2 id="employeeName" class="text-2xl font-bold mb-2">Select an Employee</h2>
         <p id="employeePoints" class="text-lg text-green-700">Their points will show here</p>
        <select id="employeeSelect" onchange="updatePointsDisplay()" class="w-full p-3 mt-4 border rounded">
        <option value="">--Select Employee--</option>
       </select>
        </section>


        <!-- All Employees Section -->
        <section class="mb-10">
            <h2 class="header-title">All Employees</h2>
            <div class="overflow-x-auto mt-6 card">
                <table class="min-w-full">
                    <thead>
                        <tr class="text-left">
                            <th class="py-3 px-4">Employee Name</th>
                            <th class="py-3 px-4">Points</th>
                            <th class="py-3 px-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="employeeTable">
                        <!-- Employees will be listed here dynamically -->
                    </tbody>
                </table>
            </div>
        </section>

        <!-- Manage Points Section -->
        <section class="mb-10">
            <h2 class="header-title">Manage Points</h2>
            <div class="flex flex-col md:flex-row gap-4">
                <div class="card flex-1 text-center">
                    <h3 class="text-xl mb-4">Add Points</h3>
                    <input type="number" id="pointsInput" placeholder="Points to add" class="w-full p-3 border rounded mb-4" />
                    <button id="addPointsButton" class="button-gradient w-full">Add Points</button>
                </div>

                <div class="card flex-1 text-center">
                    <h3 class="text-xl mb-4">Redeem Reward</h3>
                    <select id="rewardSelect" class="w-full p-3 border rounded mb-4">
                        <option value="">--Select Reward--</option>
                        <option value="50">Reward 1 (50 Points)</option>
                        <option value="100">Reward 2 (100 Points)</option>
                        <option value="150">Reward 3 (150 Points)</option>
                        <option value="200">Reward 4 (200 Points)</option>
                        <option value="250">Reward 5 (250 Points)</option>
                    </select>
                    <button id="redeemButton" class="button-gradient w-full">Redeem</button>

                    <!-- Message for Redeemed Reward -->
                    <div id="message" class="text-lg mt-4 font-bold highlight-reward"></div>
                </div>
            </div>
        </section>

        <!-- Add Employee Section -->
        <section class="mb-10">
            <h2 class="header-title">Add Employee</h2>
            <div class="card">
                <input type="text" id="newEmployeeName" placeholder="Employee Name" class="w-full p-3 border rounded mb-2" />
                <input type="number" id="newEmployeePoints" placeholder="Initial Points" class="w-full p-3 border rounded mb-2" />
                <button id="addEmployeeButton" class="button-gradient w-full">Add Employee</button>
            </div>
        </section>

    </main>

    <script>
        // JavaScript code remains the same for functionality
        const employeeSelect = document.getElementById('employeeSelect');
        const pointsInput = document.getElementById('pointsInput');
        const addPointsButton = document.getElementById('addPointsButton');
        const rewardSelect = document.getElementById('rewardSelect');
        const redeemButton = document.getElementById('redeemButton');
        const message = document.getElementById('message');
        const employeeTable = document.getElementById('employeeTable');

        const employeeNameDisplay = document.getElementById('employeeName');
        const employeePointsDisplay = document.getElementById('employeePoints');

        const newEmployeeName = document.getElementById('newEmployeeName');
        const newEmployeePoints = document.getElementById('newEmployeePoints');
        const addEmployeeButton = document.getElementById('addEmployeeButton');

        const employees = {
            1: { name: "Alice", points: 100 },
            2: { name: "Bob", points: 150 },
            3: { name: "Charlie", points: 75 },
            4: { name: "Diana", points: 200 },
            5: { name: "Ethan", points: 50 }
        };

        const rewards = {
            50: "Reward 1",
            100: "Reward 2",
            150: "Reward 3",
            200: "Reward 4",
            250: "Reward 5"
        };

        function displayEmployees() {
            employeeTable.innerHTML = '';
            for (const id in employees) {
                const employee = employees[id];
                const row = `<tr>
                    <td class="py-3 px-4">${employee.name}</td>
                    <td class="py-3 px-4">${employee.points} Points</td>
                    <td class="py-3 px-4">
                        <button class="button-gradient" onclick="deleteEmployee(${id})">Delete</button>
                    </td>
                </tr>`;
                employeeTable.innerHTML += row;
            }
        }

        function updateEmployeeSelect() {
            employeeSelect.innerHTML = '<option value="">--Select Employee--</option>';
            for (const id in employees) {
                const employee = employees[id];
                const option = document.createElement('option');
                option.value = id;
                option.textContent = employee.name;
                employeeSelect.appendChild(option);
            }
        }

        function updatePointsDisplay() {
            const selectedEmployeeId = employeeSelect.value;
            if (selectedEmployeeId) {
                const employee = employees[selectedEmployeeId];
                employeeNameDisplay.textContent = employee.name;
                employeePointsDisplay.textContent = `${employee.points} Points`;
            } else {
                employeeNameDisplay.textContent = 'Select an Employee';
                employeePointsDisplay.textContent = 'Their points will show here';
            }
        }

        function deleteEmployee(id) {
            delete employees[id];
            displayEmployees();
            updateEmployeeSelect();
        }

        function redeemReward() {
            const selectedEmployeeId = employeeSelect.value;
            const rewardPoints = parseInt(rewardSelect.value);

            if (selectedEmployeeId && rewardPoints) {
                const employee = employees[selectedEmployeeId];
                if (employee.points >= rewardPoints) {
                    employee.points -= rewardPoints;
                    message.textContent = `${employee.name} redeemed ${rewards[rewardPoints]}!`;
                    displayEmployees();
                    updateEmployeeSelect();
                    message.classList.add("highlight-reward");
                    setTimeout(() => message.classList.remove("highlight-reward"), 1000);
                } else {
                    alert("Not enough points for this reward.");
                }
            } else {
                alert("Please select an employee and reward.");
            }
        }

        addPointsButton.addEventListener("click", () => {
            const selectedEmployeeId = employeeSelect.value;
            const pointsToAdd = parseInt(pointsInput.value);

            if (selectedEmployeeId && pointsToAdd) {
                employees[selectedEmployeeId].points += pointsToAdd;
                displayEmployees();
                updateEmployeeSelect();
                pointsInput.value = '';
            } else {
                alert("Please select an employee and enter points.");
            }
        });

        redeemButton.addEventListener("click", redeemReward);
        addEmployeeButton.addEventListener("click", () => {
            const name = newEmployeeName.value;
            const points = parseInt(newEmployeePoints.value);

            if (name && points >= 0) {
                const newId = Date.now();
                employees[newId] = { name, points };
                displayEmployees();
                updateEmployeeSelect();
                newEmployeeName.value = '';
                newEmployeePoints.value = '';
            } else {
                alert("Please enter a valid employee name and points.");
            }
        });

        displayEmployees();
        updateEmployeeSelect();
    </script>

</body>

</html>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
