<?php include 'includes/header.php' ?>
<?php include 'includes/navbar.php' ?>
<?php include 'includes/sidebar.php' ?>
<div id="layoutSidenav_content">

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hr2"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
            if (isset($_POST['submit'])) {
                // Sanitize and validate input values
                $reason = htmlspecialchars(trim($_POST['reason']));
                $date = htmlspecialchars(trim($_POST['date']));
                $subject = htmlspecialchars(trim($_POST['subject']));
                $status = htmlspecialchars(trim($_POST['status']));

                // Prepare the SQL query
                $query = "INSERT INTO nominate (reason, date, subject, status) VALUES (?, ?, ?, ?)";

                if ($stmt = $conn->prepare($query)) {
                    // Bind parameters
                    $stmt->bind_param("ssss", $reason, $date, $subject, $status);

                    // Execute the query
                    if ($stmt->execute()) {
                        echo "<script>
                                Swal.fire({
                                    title: 'Success!',
                                    text: 'Nomination submitted successfully',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = 'employee-recognition.php';
                                    }
                                });
                            </script>";
                    } else {
                        // Handle query execution errors
                        echo "<script>
                                Swal.fire({
                                    title: 'Error',
                                    text: 'Error: " . $conn->error . "',
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            </script>";
                    }

                    // Close the statement
                    $stmt->close();
                } else {
                    // Handle statement preparation errors
                    echo "<script>
                            Swal.fire({
                                title: 'Error',
                                text: 'Error preparing query: " . $conn->error . "',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        </script>";
                }
            }

            $sql = "SELECT id, reason, subject, status, date FROM nominate WHERE status NOT IN ('Accepted', 'Rejected')";
            $result = $conn->query($sql);

?>
<div class="flex items-center justify-between border border-gray-300 p-4 rounded-lg mb-4 bg-white">
    <div>
        <h5 class="text-2xl font-bold text-black">
            Employee Recognition
        </h5>
        <span class="text-gray-600">
            <a href="index.php" class="text-blue-500 hover:underline">Dashboard</a> / Employee Recognition
        </span>
    </div>
</div>
<main class="container max-w-full mx-auto p-6 space-y-8">
    
    <!-- Employees List -->
    <section class="bg-white p-6 rounded-lg shadow-md w-full">
    <!-- Header with Title and Search Bar -->
    <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-semibold text-gray-700">Employees</h2>
        <div ss="flex space-x-2">
            <input type="text" placeholder="Search employees..." class="p-2 border border-gray-300 rounded-lg focus:outline-none text-black focus:border-indigo-500" />
            <button class="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 focus:outline-none">Search</button>
        </div>
    </div>

    <!-- Employees Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 w-full">
        <!-- Employee Card -->
        <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
            <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
            <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Erick Bustillo</h3>
            <p class="text-gray-600 text-center">Developer</p>
            <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
            <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
        </div>
        <!-- Employee Card -->
        <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
            <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
            <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Edrian Luangki</h3>
            <p class="text-gray-600 text-center">Developer</p>
            <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
            <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
        </div>
        <!-- Employee Card -->
        <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
            <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
            <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Raymond Lodronio</h3>
            <p class="text-gray-600 text-center">Developer</p>
            <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
            <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
        </div>
        <!-- Employee Card -->
        <div class="bg-gray-100 p-4 rounded-lg shadow-md hover:shadow-lg transition w-full max-w-full">
            <img class="w-24 h-24 rounded-full mx-auto" src="assets/img/kap.jpg" alt="John Doe">
            <h3 class="text-xl font-semibold text-gray-800 mt-4 text-center">Jerico Meca</h3>
            <p class="text-gray-600 text-center">Developer</p>
            <p class="text-gray-600 text-center">Points: <span id="john-points">50</span></p>
            <button onclick="showNominationForm(1)" class="mt-4 bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Nominate</button>
        </div>
    </div>
</section>



    <!-- Nomination Form Modal -->
    <div id="nominationModal" class="fixed inset-0 bg-gray-500 bg-opacity-50 flex justify-center items-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-lg w-full">
        <h3 class="text-2xl font-semibold text-gray-800 mb-4">Nominate an Employee</h3>
        <form id="addForm" action="employee-recognition.php" method="POST" enctype="multipart/form-data">
            <div class="mb-4">
                <label for="reason" class="block text-gray-700">Reason for Nomination</label>
                <textarea id="reason" name="reason" rows="3" class="w-full p-2 border border-gray-300 rounded-lg text-black focus:outline-none focus:border-indigo-500" placeholder="Enter the reason for recognition"></textarea>
            </div>
            <div class="mb-4 text-black">
                <label for="date" class="block text-gray-700">Date of Nomination</label>
                <input type="date" id="date" name="date" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500" />
            </div>
            <div class="mb-4 text-black">
                <label for="subject" class="block text-gray-700">Subject of Nomination</label>
                <select id="subject" name="subject" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500">
                    <option value="Mentorship and Guidance">Mentorship and Guidance</option>
                    <option value="Salary Increase">Salary Increase</option>
                    <option value="Promotion Readiness">Promotion Readiness</option>
                    <option value="Employee of the Month/Quarter/Year">Employee of the Month/Quarter/Year</option>
                    <option value="Underperformance">Underperformance</option>
                    <option value="Lack of Punctuality">Lack of Punctuality</option>
                    <option value="Negative Attitude or Behavior">Negative Attitude or Behavior</option>
                    <option value="Low Adaptability to Change">Low Adaptability to Change</option>
                </select>
            </div>
            <div class="mb-4 text-black">
                <label for="status" class="block text-gray-700">Status</label>
                <select id="status" name="status" class="w-full p-2 border border-gray-300 rounded-lg focus:outline-none focus:border-indigo-500">
                    <option value="Pending">Pending</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Scheduled">Scheduled</option>
                </select>
            </div>
            <button type="submit" name="submit" class="w-full bg-indigo-500 text-white py-2 px-4 rounded-lg hover:bg-indigo-600 focus:outline-none">Submit Nomination</button>
        </form>
        <button onclick="closeNominationForm()" class="mt-4 text-red-600">Cancel</button>
    </div>
    </div>

            
          <!-- Nominations Section -->
        <section class="bg-white p-6 rounded-lg shadow-md">
                    <h2 class="text-2xl font-semibold text-gray-700 mb-4">Nominations</h2>
                <div class="space-y-4">
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $bgColor = "";
                            $borderColor = "";
                            $textColor = "";

                            // Set styles based on the nomination's status
                            switch ($row["status"]) {
                                case "Pending":
                                    $bgColor = "bg-yellow-100";
                                    $borderColor = "border-yellow-500";
                                    $textColor = "text-yellow-700";
                                    break;
                                case "Scheduled":
                                    $bgColor = "bg-blue-100";
                                    $borderColor = "border-blue-500";
                                    $textColor = "text-blue-700";
                                    break;
                                case "Follow-up":
                                    $bgColor = "bg-pink-100";
                                    $borderColor = "border-pink-500";
                                    $textColor = "text-pink-700";
                                    break;
                            }
                    ?>
                            <!-- Nomination Box -->
                            <div id="nomination-<?php echo $row['id']; ?>" class="<?php echo "$bgColor p-4 rounded-lg shadow border-l-4 $borderColor"; ?>">
                                <h3 class="font-semibold <?php echo $textColor; ?>"><?php echo htmlspecialchars($row["status"]); ?> Nomination</h3>
                                <p class="text-gray-600">Subject: <?php echo htmlspecialchars($row["subject"]); ?></p>
                                <p class="text-gray-600">Reason: <?php echo htmlspecialchars($row["reason"]); ?></p>
                                <p class="text-gray-600">Date: <?php echo htmlspecialchars($row["date"]); ?></p>
                                <div class="flex justify-end space-x-2 mt-4">
                                <button onclick="updateStatus(<?php echo $row['id']; ?>, 'Accepted')" class="bg-green-500 text-white py-1 px-4 rounded hover:bg-green-600">Accept</button>
                                    <button onclick="updateStatus(<?php echo $row['id']; ?>, 'Rejected')" class="bg-red-500 text-white py-1 px-4 rounded hover:bg-red-600">Reject</button>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p class='text-gray-600'>No nominations found.</p>";
                    }
                    ?>
                </div>
        </section>
    
                    <!-- TIMELINE -->
                <section class="bg-white p-6 rounded-lg shadow-md mt-6">
            <h2 class="text-2xl font-semibold text-gray-700 mb-4">Recognition Timeline</h2>
            <div id="timeline" class="space-y-4">
                <?php
                // Fetch accepted or rejected nominations for the timeline
                $sql = "SELECT id, reason, subject, status, date FROM nominate WHERE status IN ('Accepted', 'Rejected')";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $bgColor = $row["status"] === "Accepted" ? "bg-green-100" : "bg-red-100";
                        $borderColor = $row["status"] === "Accepted" ? "border-green-500" : "border-red-500";
                        $textColor = $row["status"] === "Accepted" ? "text-green-700" : "text-red-700";
                        ?>
                        <!-- Timeline Box for Accepted or Rejected Status -->
                        <div class="<?php echo "$bgColor p-4 rounded-lg shadow border-l-4 $borderColor"; ?>">
                            <h3 class="font-semibold <?php echo $textColor; ?>"><?php echo htmlspecialchars($row["status"]); ?> Nomination</h3>
                            <p class="text-gray-600">Subject: <?php echo htmlspecialchars($row["subject"]); ?></p>
                            <p class="text-gray-600">Reason: <?php echo htmlspecialchars($row["reason"]); ?></p>
                            <p class="text-gray-600">Date: <?php echo htmlspecialchars($row["date"]); ?></p>
                        </div>
                        <?php
                    }
                } else {
                    echo "<p class='text-gray-600'>No recognitions in the timeline.</p>";
                }
                ?>
            </div>
        </section>


                <script>
                    function updateStatus(id, newStatus) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you want to mark this nomination as " + newStatus + "?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, change it!',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "update.php", true);
                        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function () {
                            if (xhr.readyState === 4 && xhr.status === 200) {
                                const nominationBox = document.getElementById("nomination-" + id);
                                const timeline = document.getElementById("timeline");
                                if (newStatus === "Accepted") {
                                    nominationBox.className = "bg-green-100 p-4 rounded-lg shadow border-l-4 border-green-500";
                                    nominationBox.querySelector(".font-semibold").className = "font-semibold text-green-700";
                                } else if (newStatus === "Rejected") {
                                    nominationBox.className = "bg-red-100 p-4 rounded-lg shadow border-l-4 border-red-500";
                                    nominationBox.querySelector(".font-semibold").className = "font-semibold text-red-700";
                                }
                                nominationBox.querySelector(".flex").remove();
                                timeline.appendChild(nominationBox);
                                
                                // Show success SweetAlert
                                Swal.fire(
                                    'Updated!',
                                    'The nomination has been ' + newStatus + '!',
                                    'success'
                                );
                            }
                        };
                        xhr.send("id=" + id + "&status=" + newStatus);
                    } else {
                        // If canceled, show an info message
                        Swal.fire(
                            'Cancelled',
                            'The nomination status was not changed.',
                            'info'
                        );
                    }
                });
            }

        </script>
</main>
<script>
        // Function to show the nomination form
        function showNominationForm(employeeId) {
            currentNomineeId = employeeId;
            document.getElementById('nominationModal').classList.remove('hidden');
        }

        // Function to close the nomination form
        function closeNominationForm() {
            document.getElementById('nominationModal').classList.add('hidden');
        }
</script>


<?php include 'includes/script.php' ?>
<?php include 'includes/footer.php' ?>
